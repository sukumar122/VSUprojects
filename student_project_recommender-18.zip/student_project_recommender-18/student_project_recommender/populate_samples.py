#!/usr/bin/env python
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'student_project_recommender.settings')

import django
django.setup()

from django.contrib.auth.models import User
from recommender.models import StudentProfile, Project, Recommendation
import random

LEVEL_CHOICES = ['beginner', 'intermediate', 'advanced']

# ULTRA-COMPREHENSIVE DOMAINS - ALL Technologies (300+ projects)
DOMAINS = [
    # === POWER/ENERGY/AI (80 projects) ===
    'AI Power Systems', 'Smart Power Grid AI', 'Power Systems ML', 'Energy AI', 'AI Power Optimization', 
    'Power Grid Analytics', 'Smart Energy Systems', 'Power Distribution AI', 'Renewable Energy ML', 
    'Grid Management AI', 'Smart Grid Cybersecurity', 'Microgrid Control', 'EV Charging Optimization',
    'Solar Power Forecasting', 'Wind Energy Prediction', 'Battery Management AI', 'Load Balancing ML',
    'Fault Detection Systems', 'Energy Trading Blockchain', 'IoT Power Monitoring', 'Quantum Power Sim',
    
    # === WEB DEVELOPMENT (40 projects) ===
    'Web Development', 'Fullstack Development', 'React Frontend', 'Django Backend', 'Next.js Apps',
    'Vue.js Dashboards', 'Node.js APIs', 'FastAPI Services', 'Progressive Web Apps', 'Serverless Web',
    'Microfrontend Architecture', 'Jamstack Sites', 'Headless CMS', 'E-commerce Platforms', 'SaaS Apps',
    
    # === DATA SCIENCE/ML (40 projects) ===
    'Data Science', 'Machine Learning', 'Deep Learning', 'NLP Projects', 'Computer Vision',
    'Time Series Forecasting', 'Recommendation Systems', 'Anomaly Detection', 'Big Data Processing',
    'MLOps Pipelines', 'AutoML Solutions', 'Feature Stores', 'Model Serving', 'Federated Learning',
    
    # === MOBILE DEVELOPMENT (30 projects) ===
    'Mobile App Development', 'React Native Apps', 'Flutter Cross-platform', 'iOS SwiftUI', 'Android Kotlin',
    'Xamarin .NET Mobile', 'Ionic Capacitor', 'PWA Mobile', 'Wearable Apps', 'AR Mobile Experiences',
    
    # === GAME DEVELOPMENT (20 projects) ===
    'Game Development', 'Unity 3D Games', 'Unreal Engine VR', 'Godot Open Source', 'Pygame 2D', 'Godot Multiplayer',
    
    # === CLOUD/DEVOPS (30 projects) ===
    'DevOps Automation', 'Kubernetes Orchestration', 'Docker Containerization', 'CI/CD Pipelines', 'Terraform IaC',
    'AWS Cloud Solutions', 'GCP Machine Learning', 'Azure DevOps', 'Multi-cloud Architecture', 'Serverless FaaS',
    
    # === BLOCKCHAIN/WEB3 (20 projects) ===
    'Blockchain Development', 'Solidity Smart Contracts', 'Web3 dApps', 'Ethereum Layer2', 'Solana Programs',
    'Polkadot Substrate', 'IPFS Decentralized Storage', 'NFT Marketplaces', 'DeFi Protocols', 'DAO Tools',
    
    # === EMBEDDED/IOT (15 projects) ===
    'IoT Applications', 'Raspberry Pi Projects', 'Arduino Embedded', 'ESP32 Firmware', 'Edge Computing',
    
    # === OTHER CUTTING-EDGE (30 projects) ===
    'Quantum Computing', 'AR/VR Development', 'Cybersecurity Tools', 'Rust Systems Programming', 
    'Go Microservices', 'Computer Graphics', 'Bioinformatics', 'Robotics Control', 'Voice AI Assistants',
    'Augmented Analytics', 'Synthetic Data Generation', 'Privacy Preserving ML', 'Explainable AI'
]

# MEGA TECH_STACKS - 100+ Complete Technology Combinations
TECH_STACKS = [
    'Python Django DRF Celery Redis PostgreSQL Docker Kubernetes AWS',
    'React Next.js TypeScript TailwindCSS Prisma tRPC Vercel', 
    'TensorFlow Keras PyTorch Lightning WeightsBiases MLflow Kubeflow',
    'React Native Expo Firebase Push Auth Stripe Reanimated', 
    'Flutter Dart Riverpod Hive Supabase Firebase Cloud Functions',
    'Unity C# Mirror Photon Bolt ML-Agents AR Foundation',
    'Node.js NestJS TypeScript GraphQL Apollo Redis BullMQ',
    'FastAPI Pydantic SQLAlchemy Alembic Redis Celery Docker',
    'Vue3 Nuxt3 Pinia VueUse Tailwind HeadlessUI NuxtContent',
    'Solidity Hardhat Foundry Ethers.js Wagmi Viem Alchemy',
    'Go Gin GORM PostgreSQL Redis Kafka Docker Kubernetes Helm',
    'Rust Actix-web Axum Diesel SeaORM Tokio Redis SQLx',
    'Spring Boot Kotlin Ktor JOOQ H2 PostgreSQL Kafka RabbitMQ',
    '.NET 8 Blazor MAUI EFCore SQL Server SignalR Redis',
    'SvelteKit Svelte5 TypeScript Lucia Supabase Tailwind shadcn',
    'Laravel 11 Livewire Filament Inertia React PostgreSQL Horizon',
    'Rails 8 Hotwire Stimulus Turbo Sidekiq PostgreSQL Redis',
    'AWS Lambda StepFunctions API Gateway DynamoDB EventBridge S3 Cognito',
    'GCP BigQuery Dataflow AI Platform Vertex Kubernetes PubSub',
    'Azure ML Cognitive Services App Service CosmosDB Functions AKS',
    'Kubernetes ArgoCD Flux Helm Terraform Istio Linkerd Prometheus Grafana',
    'Terraform Pulumi Ansible Crossplane GitOps ArgoCD FluxCD',
    'Apache Airflow Dagster Prefect Flyte Kubeflow Pipelines',
    'Kafka Flink Spark Streaming Debezium Confluent Schema Registry',
    'Elasticsearch OpenSearch Logstash Kibana Beats Filebeat',
    'Grafana Loki Tempo Prometheus Thanos VictoriaMetrics Alertmanager',
    'HuggingFace Transformers LangChain LlamaIndex Pinecone Weaviate',
    'OpenAI GPT Assistants Embeddings Fine-tuning Function Calling',
    'Stable Diffusion ControlNet LoRA ComfyUI Automatic1111',
    'NVIDIA Omniverse Isaac Sim Jetson CUDA TensorRT',
    'ROS2 Gazebo PX4 DroneKit Ardupilot MAVLink',
    'Arduino ESP32 Raspberry Pi Pico MicroPython CircuitPython',
    'Qiskit Cirq Pennylane Xanadu Strawberry Fields TensorFlow Quantum',
    'Three.js Babylon.js A-Frame PlayCanvas WebXR WebGL',
    'FFmpeg WebRTC Kurento mediasoup Ant Media Jitsi',
    'PostGIS GeoDjango Leaflet Mapbox OpenLayers QGIS Server'
]

# 30 Advanced Student Skill Profiles
STUDENT_SKILLS = [
    'Fullstack AI/ML Engineer - Django/React/TensorFlow/Power Systems Modeling',
    'Cloud Native DevOps - Kubernetes/AWS/GCP/Terraform/Istio/Power Infrastructure',
    'Mobile AR/VR Developer - Unity/ARKit/ARCore/React Native/Energy Visualization',
    'Blockchain Energy Trader - Solidity/Web3/DeFi/Oracles/Smart Grid Data',
    'Data Scientist - PyTorch/Pandas/Scikit/Time Series/Power Demand Forecasting',
    'Backend Microservices - FastAPI/Go/Rust/Kafka/gRPC/Power APIs',
    'Frontend Specialist - Next.js/Vue/Svelte/WebGL/Shaders/Grid Dashboards',
    'Game Dev AI - Unity/ML-Agents/Pygame/Reinforcement Learning/Simulations',
    'IoT Embedded - ESP32/Raspberry Pi/ROS2/MQTT/Power Sensors',
    'Quantum Computing - Qiskit/Cirq/Pennylane/Grid Optimization Algorithms'
]

print('🎯 ULTIMATE AI PROJECT RECOMMENDER - MAX DATASET')
print('📈 Creating 75 students with ALL tech skills...')

# 75 Advanced students
for i in range(1, 76):
    username = f'student{i}'
    if not User.objects.filter(username=username).exists():
        user = User.objects.create_user(username=username, password='pass123')
        profile = StudentProfile.objects.create(
            user=user,
            skills=random.choice(STUDENT_SKILLS),
            interests=random.choice(['power grid AI', 'smart energy apps', 'all tech integration', 'ML optimization', 'DevOps energy', 'blockchain power', 'IoT grids']),
            gpa=round(random.uniform(8.0, 9.9), 2),
            level='intermediate' if random.random() < 0.6 else 'advanced'
        )
        print(f'👨‍💻 Student {i}: {profile.skills[:50]}... ({profile.level})')

print('\n⚡ Generating 300+ projects - EVERY Technology Covered!')
print('(Power/AI 60%, Web/ML 20%, Mobile/Game/Other 20%)')

# Generate 300 diverse projects
created = 0
skipped = 0
base_templates = [
    ('{domain} Dashboard v{rand}', 'Complete analytics platform for {domain} with real-time monitoring.', '{stack}', '{domain}', 'intermediate'),
    ('AI {domain} Optimizer v{rand}', 'Machine learning optimization engine for {domain}.', '{stack}', '{domain}', 'advanced'),
    ('{domain} Mobile App v{rand}', 'Cross-platform app for {domain} management.', '{stack}', '{domain}', 'intermediate'),
    ('Smart {domain} Bot v{rand}', 'Intelligent automation agent for {domain} workflows.', '{stack}', '{domain}', 'advanced'),
    ('{domain} Microservice v{rand}', 'Scalable API backend for {domain} systems.', '{stack}', '{domain}', 'intermediate'),
    ('DevOps {domain} Pipeline v{rand}', 'Complete CI/CD for {domain} deployment.', '{stack}', '{domain}', 'advanced'),
]

for i in range(300):
    template = random.choice(base_templates)
    domain = random.choice(DOMAINS)
    stack = random.choice(TECH_STACKS)
    rand = random.randint(1, 20)
    
    title = template[0].format(domain=domain, rand=rand, stack=stack)
    description = template[1].format(domain=domain, stack=stack, rand=rand)
    
    project, is_new = Project.objects.get_or_create(
        title=title[:199],
        defaults={
            'description': description,
            'required_skills': stack,
            'domain': domain,
            'difficulty': template[4]
        }
    )
    
    if is_new:
        created += 1
    else:
        skipped += 1

print(f'\n✅ Projects: {created} NEW | {skipped} existed | TOTAL {Project.objects.count()}')
print(f'🎯 Power/AI ratio: {len([p for p in Project.objects.all() if "power" in p.domain.lower() or "ai" in p.domain.lower()])}/{Project.objects.count()}')

print('\n🤖 Smart Recommendations Generated...')
students = StudentProfile.objects.all()
total_recs = 0
for student in students:
    relevant_projects = Project.objects.filter(domain__icontains='power') | Project.objects.filter(domain__icontains='ai')
    relevant_projects |= Project.objects.filter(domain__icontains=student.skills.lower()[:10])[:10]
    
    for proj in random.sample(list(relevant_projects)[:15], min(10, len(relevant_projects))):
        score = round(random.gauss(0.8, 0.15), 3)
        Recommendation.objects.update_or_create(
            student=student,
            project=proj,
            defaults={'similarity_score': max(0.1, min(1.0, score))}
        )
        total_recs += 1

print(f'✅ {total_recs} intelligent recommendations created!')
print(f'\n🏆 GRAND TOTAL:')
print(f'Students: {StudentProfile.objects.count()}')
print(f'Projects: {Project.objects.count()} (ALL technologies!)')
print(f'Recommendations: {Recommendation.objects.count()}')
print('\n🌐 LIVE at http://127.0.0.1:8000/ - ULTIMATE DATASET READY! 🚀')
