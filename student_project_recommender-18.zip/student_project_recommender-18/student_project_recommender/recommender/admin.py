from django.contrib import admin
from .models import StudentProfile, Project, Recommendation


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'gpa', 'level')
    search_fields = ('user__username', 'skills', 'interests', 'level')
    list_filter = ('gpa', 'level')


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'domain', 'difficulty', 'created_at')
    search_fields = ('title', 'domain', 'required_skills', 'difficulty')
    list_filter = ('domain', 'difficulty')
    ordering = ('-created_at',)


@admin.register(Recommendation)
class RecommendationAdmin(admin.ModelAdmin):
    list_display = ('student', 'project', 'similarity_score')
    search_fields = ('student__user__username', 'project__title')
    ordering = ('-similarity_score',)
