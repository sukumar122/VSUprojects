from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import StudentProfile, Project, Recommendation, LEVEL_CHOICES
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# =========================
# REGISTER
# =========================
def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('register')

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        messages.success(request, "Account created successfully")
        return redirect('login')

    return render(request, 'register.html')


# =========================
# LOGIN
# =========================
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            return redirect('profile')
        else:
            messages.error(request, "Invalid username or password")

    return render(request, 'login.html')


# =========================
# LOGOUT
# =========================
def logout_view(request):
    logout(request)
    return redirect('login')


# =========================
# PROFILE (Manual Form)
# =========================
@login_required
def profile_view(request):
    if request.method == 'POST':
        skills = request.POST.get('skills')
        interests = request.POST.get('interests')
        gpa = request.POST.get('gpa')
        level = request.POST.get('level')

        StudentProfile.objects.update_or_create(
            user=request.user,
            defaults={
                'skills': skills,
                'interests': interests,
                'gpa': float(gpa),
                'level': level
            }
        )

        return redirect('recommendations')

    return render(request, 'dashboard.html')


@login_required
def add_project_view(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        required_skills = request.POST.get('required_skills')
        difficulty = request.POST.get('difficulty')
        
        Project.objects.create(
            title=title,
            description=description,
            required_skills=required_skills,
            domain="AI Power Systems",
            difficulty=difficulty
        )
        messages.success(request, "Project added successfully!")
        return redirect('profile')
    
    return render(request, 'add_project.html')


# =========================
# PROJECT DETAIL
# =========================
@login_required
def project_detail_view(request, pk):
    try:
        profile = StudentProfile.objects.get(user=request.user)
    except StudentProfile.DoesNotExist:
        messages.warning(request, 'Please complete your profile first.')
        return redirect('profile')

    project = Project.objects.get(pk=pk)

    rec_score = None
    try:
        rec = Recommendation.objects.get(student=profile, project=project)
        rec_score = rec.similarity_score
    except Recommendation.DoesNotExist:
        pass

    context = {
        'project': project,
        'rec_score': rec_score,
        'profile': profile
    }
    return render(request, 'project_detail.html', context)


# =========================
# RECOMMENDATIONS
# =========================
@login_required
def recommendation_view(request):

    try:
        profile = StudentProfile.objects.get(user=request.user)
    except StudentProfile.DoesNotExist:
        return redirect('profile')

    # Filter by level and power systems domain
    projects = Project.objects.filter(
        difficulty=profile.level
    ).filter(domain__icontains='power').order_by('-created_at')

    if profile.gpa > 8.0:
        # High GPA unlocks advanced projects even if beginner
        projects = projects | Project.objects.filter(
            difficulty='advanced', domain__icontains='power'
        )

    projects = projects.distinct()

    if not projects.exists():
        messages.warning(request, "No matching AI Power Systems projects for your level.")
        return render(request, 'recommendations.html', {'results': [], 'profile': profile})

    project_texts = [
        p.description + " " + p.required_skills for p in projects
    ]

    vectorizer = TfidfVectorizer()
    project_vectors = vectorizer.fit_transform(project_texts)

    student_text = profile.skills + " " + profile.interests + " " + profile.level
    student_vector = vectorizer.transform([student_text])

    similarity = cosine_similarity(student_vector, project_vectors)

    results = []
    for idx, score in enumerate(similarity[0]):
        percentage_score = round(float(score) * 100, 2)
        
        # Domain boost for AI Power Systems
        if 'power' in projects[idx].domain.lower() or 'ai' in projects[idx].domain.lower():
            percentage_score *= 1.3

        Recommendation.objects.update_or_create(
            student=profile,
            project=projects[idx],
            defaults={'similarity_score': percentage_score}
        )

        results.append((projects[idx], percentage_score))

    results.sort(key=lambda x: x[1], reverse=True)
    top_results = results[:5]

    return render(request, 'recommendations.html', {'results': top_results, 'profile': profile})
