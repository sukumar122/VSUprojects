from django.urls import path
from . import views

urlpatterns = [
    path('', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('add-project/', views.add_project_view, name='add_project'),
    path('recommendations/', views.recommendation_view, name='recommendations'),
    path('project/<int:pk>/', views.project_detail_view, name='project_detail'),
]
