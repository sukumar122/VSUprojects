from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

LEVEL_CHOICES = [
    ('beginner', 'Beginner'),
    ('intermediate', 'Intermediate'),
    ('advanced', 'Advanced'),
]


class StudentProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="profile"
    )
    skills = models.TextField()
    interests = models.TextField()
    gpa = models.FloatField(
        validators=[MinValueValidator(0.0), MaxValueValidator(10.0)]
    )
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default='intermediate')

    def __str__(self):
        return self.user.username


class Project(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    required_skills = models.TextField()
    domain = models.CharField(max_length=100)
    difficulty = models.CharField(max_length=20, choices=LEVEL_CHOICES, default='intermediate')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title


class Recommendation(models.Model):
    student = models.ForeignKey(
        StudentProfile,
        on_delete=models.CASCADE,
        related_name="recommendations"
    )
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE
    )
    similarity_score = models.FloatField()

    class Meta:
        unique_together = ('student', 'project')
        ordering = ['-similarity_score']

    def __str__(self):
        return f"{self.student.user.username} - {self.project.title}"
